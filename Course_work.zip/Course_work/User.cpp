#include <iostream>

#include <algorithm>

#include "User.h"

std::vector<User> User::registeredUsers;
const int User::maxUsers;

User::User() {}

User::User(const std::string& login, const std::string& password, const std::string& fullName, const std::string& address, const std::string& phone) 
    : login(login), password(password), full_name(fullName), address(address), phone(phone) {}

std::string User::getStringFromUser(const std::string& message) 
{
    std::string input;
    std::cout << message;
    std::cin >> input;
    return input;
}

int User::getModeFromUser() 
{
    int mode;
    std::cout << "Select mode (1 - User, 2 - Admin): ";
    std::cin >> mode;
    return mode;
}

void User::register_user() 
{
    bool isUniqueLogin = false;

    while (!isUniqueLogin) 
    {
        std::string newLogin = getStringFromUser("Enter login: ");

        if (isLoginTaken(newLogin)) 
        {
            std::cout << "This login is already taken. Please choose another one." << std::endl;
        } 
        else
        {
            isUniqueLogin = true;
            login = newLogin;
            
            password = getStringFromUser("Enter password: ");

            std::cout << "Enter full name: ";
            std::cin.ignore();
            std::getline(std::cin, full_name);
            //std::cout << "Enter address: ";
            //std::getline(std::cin, address);
            //phone = getStringFromUser("Enter phone number: ");

            
            while (true) 
            {
                std::string address = User::getStringFromUser("Enter your email address: ");
                if (validateEmail(address)) 
                {
                    this->address = address;
                    break;
                } 
                else 
                {
                    std::cout << "Invalid email address format. Please try again." << std::endl;
                }
            }

            while (true) 
            {
                std::string phone = User::getStringFromUser("Enter your phone number (+380 00 000 00 00): ");
                if (validatePhoneNumber(phone)) 
                {
                    this->phone = phone;
                    break;
                } 
                else 
                {
                    std::cout << "Invalid phone number format. Please try again." << std::endl;
                }
            }

            registeredUsers.push_back(*this); // Добавляем пользователя в список зареганых
        }
    }  
            
}

bool User::validateEmail(const std::string& email) 
{
    int atIndex = email.find('@');
    int dotIndex = email.rfind('.');

    bool hasAt = (atIndex != std::string::npos);
    bool hasDot = (dotIndex != std::string::npos);
    bool dotAfterAt = (hasAt && hasDot && dotIndex > atIndex);

    return dotAfterAt;
}

bool User::validatePhoneNumber(const std::string& phoneNumber) 
{
    return phoneNumber.find("+380") == 0 && phoneNumber.size() == 13;
}


std::string User::getFullName() const { return full_name; }

bool User::authorize() 
{
    std::string inputLogin = getStringFromUser("Enter login: ");
    std::string inputPassword = getStringFromUser("Enter password: ");

    return (inputLogin == login && inputPassword == password);
}

bool User::isAuthorized() const { return !login.empty() && !password.empty(); }

void User::setLogin(const std::string& newLogin) { login = newLogin; }

const std::string& User::getPassword() const { return password; }

void User::setPassword(const std::string& newPassword) { password = newPassword; }

void User::delete_user(const std::string& login) 
{
    auto it = std::remove_if(registeredUsers.begin(), registeredUsers.end(), 
        [&](const User& user) { return user.login == login; });

    if (it != registeredUsers.end()) 
    {
        registeredUsers.erase(it, registeredUsers.end());
        std::cout << "User deleted successfully!" << std::endl;
    } 
    else 
    {
        std::cout << "User not found!" << std::endl;
    }
}

bool User::isLoginTaken(const std::string& login) 
{
    auto it = std::find_if(registeredUsers.begin(), registeredUsers.end(),
        [&](const User& user) { return user.login == login; });

    return it != registeredUsers.end();
}

int User::getFinalScore() const
{
    return finalScore;
}

std::string User::getLogin() const {
    return login;
}
