#pragma once

struct File_actions
{
    static void import_From_file(); 
    static void export_To_file(); 
};

