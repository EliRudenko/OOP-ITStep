#include "Test_Interface.h"
#include "User_Interface.h"

#include <iostream>

void TestInterface::startTesting() 
{
    loadTests();

    while (true) 
    {
        displayCategories();

        int categoryChoice = getUserChoice(0, categories.size());
        if (categoryChoice == 0) break;

        displaySubCategories(categoryChoice - 1);

        int subCategoryChoice = getUserChoice(0, subCategories[categoryChoice - 1].size());
        if (subCategoryChoice == 0) continue;

        while (true) 
        {
            displayQuestions(categoryChoice - 1, subCategoryChoice - 1);

            std::cout << "Do you want to take another test in this category? (Y/N): ";
            std::string choice;
            std::cin >> choice;

            if (choice != "Y" && choice != "y") { break; }
        }
    }
}


void TestInterface::loadTests() 
{
    tests.resize(categories.size());
    tests[0].resize(subCategories[0].size());

    tests[0][0].push_back({"Ten horses are participating in a race. How many possible combinations for the top three horses are there?", {"A 100", "B 60", "C 120"}, 'C'});
    tests[0][0].push_back({"In how many ways can 7 different books be arranged on a bookshelf?", {"A 5040", "B 70", "C 2032"}, 'A'});
    tests[0][0].push_back({"There are four identical seats for passengers on a carousel. How many ways are there to seat 4 passengers for a ride?", {"A 24", "B 35", "C 18"}, 'B'});

}

void TestInterface::displayCategories() 
{
    std::cout << "Select a category (enter the number):\n";
    for (size_t i = 0; i < categories.size(); ++i) { std::cout << i + 1 << ". " << categories[i] << "\n"; }
    std::cout << "0. Back\n";
}

void TestInterface::displaySubCategories(int categoryIndex) 
{
    std::cout << "Select a subcategory (enter the number):\n";
    for (size_t i = 0; i < subCategories[categoryIndex].size(); ++i) { std::cout << i + 1 << ". " << subCategories[categoryIndex][i] << "\n"; }
    std::cout << "0. Back\n";
}

void TestInterface::displayQuestions(int categoryIndex, int subCategoryIndex) 
{
    int correctAnswers = 0;

    for (const Question& question : tests[categoryIndex][subCategoryIndex]) 
    {
        std::cout << question.text << "\n";

        for (const std::string& option : question.options) { std::cout << option << "\n"; }

        std::cout << "Your answer: ";
        char userAnswer;
        std::cin >> userAnswer;

        if (userAnswer == question.correctOption) 
        {
            std::cout << "Correct!\n";
            ++correctAnswers;
        } else { std::cout << "Incorrect. Correct answer: " << question.correctOption << "\n"; }
    }

    displayResults(categoryIndex, subCategoryIndex, correctAnswers);
}

void TestInterface::displayResults(int categoryIndex, int subCategoryIndex, int correctAnswers) 
{
    std::cout << "Results:\n";
    std::cout << "Correct answers: " << correctAnswers << " out of " << tests[categoryIndex][subCategoryIndex].size() << "\n";
    std::cout << "Press 0 to go back to the main menu or any other key to choose another test.\n";

    int choice;
    std::cin >> choice;

    if (choice == 0) { return; }
}

int TestInterface::getUserChoice(int min, int max) 
{
    int choice;
    while (true) 
    {
        std::cin >> choice;
        if (choice >= min && choice <= max) { return choice; }

        std::cout << "Incorrect input. Please try again: ";
        std::cin.clear();
        while (std::cin.get() != '\n') {}
    }
    return -1; 
}

