#pragma once

#include <string>
#include <map>


#include "User.h"




class Question_for_actions 
{
public:
    std::string text;
    std::vector<std::string> options;
    char correctOption;

    Question_for_actions(const std::string& t, const std::vector<std::string>& o, char c) : text(t), options(o), correctOption(c) {}
};

class Admin : public User 
{
    std::vector<std::string> categories;
    std::vector<std::vector<std::string>> tests;
public:

    Admin();
    Admin(const std::string& login, const std::string& encryptedPassword);

    bool authorize();
    bool authorize_admin(const std::string& inputLogin, const std::string& inputPassword);
    bool isAuthorized() const;


    void change_admin_password(const std::string& newAdminPassword);
    void change_admin_login(const std::string& newAdminLogin);

    void create_user();


    void addCategory(const std::string& categoryName);
    void addTestToCategory(const std::string& categoryName, const std::string& testName);
    void addQuestionToTest(const std::string& categoryName, const std::string& testName, const std::string& questionText, const std::vector<std::string>& options, char correctOption);

    std::vector<std::string> getCategories() const {  return categories;}

    bool areNewCategoriesAdded();
    bool areNewTestsAdded();
    
};
