#include<iostream>

/*
#include "User.cpp"
#include "Admin.cpp"
#include "User_interface.cpp"
#include "Test_Interface.cpp"
#include "Category.cpp"
#include "Question.h"
*/

#include "File_connection_library.h"

int main() 
{
    UserInterface userInterface;
    TestInterface testInterface;

    userInterface.for_main(); 

    return 0;
}

