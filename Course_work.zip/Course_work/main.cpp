#include<iostream>

#include "File_connection_library.h"

int main() 
{
    UserInterface userInterface;
    TestInterface testInterface;

    userInterface.for_main(); 

    return 0;
}

 