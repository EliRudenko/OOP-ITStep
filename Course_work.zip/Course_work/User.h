#pragma once

#include <string>
#include <vector>

class User 
{
protected:
    static const int maxUsers = 100;
    static std::vector<User> registeredUsers;

    std::string login;
    std::string password;
    std::string full_name;
    std::string address;
    std::string phone;

    int finalScore;

public:
    User();
    User(const std::string& login, const std::string& password, const std::string& fullName, const std::string& address, const std::string& phone);

    void register_user();
    bool validateEmail(const std::string& email);
    bool validatePhoneNumber(const std::string& phoneNumber);


    bool authorize();
    void setLogin(const std::string& newLogin);

    static int getModeFromUser();
    static std::string getStringFromUser(const std::string& message);
    std::string getFullName() const;
    std::string getLogin() const;

    static bool isLoginTaken(const std::string& login);

    bool isAuthorized() const;
    const std::string& getPassword() const;
    void setPassword(const std::string& newPassword);

    void delete_user(const std::string& login);

    int getFinalScore() const;
};